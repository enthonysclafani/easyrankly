<?php
/** URL and redirect normalization helpers. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Normalizes redirect source paths and validates targets. */
final class ERankly_Redirects_Normalizer {
	/** Per-pattern PCRE limits used to contain backtracking-heavy redirects. */
	private const PCRE_LIMITS = '(*LIMIT_MATCH=100000)(*LIMIT_DEPTH=100000)';

	/**
 * Valid redirect status codes.
 *
 * @var int[]
 */
	public const VALID_STATUS_CODES = array( 301, 302, 307, 308, 410, 451 );

	/**
 * Supported source-matching strategies.
 *
 * @var string[]
 */
	public const VALID_MATCH_TYPES = array( 'exact', 'wildcard', 'regex' );

	/**
 * Supported query-string strategies.
 *
 * @var string[]
 */
	public const VALID_QUERY_MODES = array( 'ignore', 'preserve', 'exact' );

	/**
 * Supported trailing-slash strategies.
 *
 * @var string[]
 */
	public const VALID_TRAILING_SLASH_MODES = array( 'ignore', 'exact' );

	/**
 * Status codes that terminate the request with a status header only. they carry no Location and therefore need
 * no target URL.
 *
 * @var int[]
 */
	public const STATUS_ONLY_CODES = array( 410, 451 );

	/**
 * Human-readable labels for each supported status code.
 *
 * @var array<int,string>
 */
	public const STATUS_CODE_LABELS = array(
		301 => '301: Moved Permanently',
		302 => '302: Found (Temporary)',
		307 => '307: Temporary Redirect',
		308 => '308: Permanent Redirect',
		410 => '410: Gone',
		451 => '451: Unavailable For Legal Reasons',
	);

	public static function status_code_label( int $code ): string {
		return self::STATUS_CODE_LABELS[ $code ] ?? (string) $code;
	}

	/** @param string $path Raw path or URL. */
	public static function normalize_path( string $path ): string {
		return self::normalize_match_path( $path, false, 'ignore' );
	}

	/**
 * @param string $path             Raw path or URL.
 * @param bool   $case_sensitive   Preserve case when true.
 */
	public static function normalize_match_path( string $path, bool $case_sensitive = false, string $trailing_slash = 'ignore' ): string {
		$path = trim( $path );
		$path = self::extract_path( $path );
		$path = rawurldecode( $path );
		$path = preg_replace( '/\s+/', '', $path ) ?? $path;
		$path = '/' . ltrim( $path, '/' );
		$path = preg_replace( '#/+#', '/', $path ) ?? $path;
		if ( 'exact' !== $trailing_slash ) {
			$path = '/' === $path ? '/' : untrailingslashit( $path );
		}

		return $case_sensitive ? $path : strtolower( $path );
	}

	/**
 * Normalizes a request path for capture replacement without lowercasing. Case-insensitive rules still match via
 * pattern flags, but backreferences should preserve the original request casing.
 *
 * @param string $path             Raw path or URL.
 * @param bool   $case_sensitive   Unused; kept for call-site symmetry.
 */
	public static function normalize_match_path_for_capture( string $path, bool $case_sensitive = false, string $trailing_slash = 'ignore' ): string {
		unset( $case_sensitive );

		return self::normalize_match_path( $path, true, $trailing_slash );
	}

	public static function extract_query( string $uri ): string {
		$query = wp_parse_url( $uri, PHP_URL_QUERY );

		return is_string( $query ) ? $query : '';
	}

	/**
 * Normalize source data before persistence. Regex patterns are trimmed and made path-like, but the expression
 * body is otherwise preserved so character classes and modifiers remain meaningful. Wildcard patterns are
 * lowercased and stripped of the query string while the literal '*' markers are kept intact.
 *
 * @param string $source_path Raw source path, regex, or wildcard.
 * @param bool   $is_regex    Whether this source is a manual regex.
 * @param bool   $is_wildcard Whether this source uses wildcard (*) syntax.
 * @param bool   $case_sensitive Whether matching preserves letter case.
 * @param string $trailing_slash How literal paths treat a trailing slash.
 */
	public static function normalize_source( string $source_path, bool $is_regex, bool $is_wildcard = false, bool $case_sensitive = false, string $trailing_slash = 'ignore' ): string {
		if ( $is_regex ) {
			// Do NOT call wp_unslash() here. The caller has already unslashed the raw POST
			// value (admin path) or the data arrives from JSON with no WordPress-added slashes
			// (import path). A second unslash would corrupt backslashes in patterns like \d, \..
			// Do NOT strip a "query string" either: '?' is a common regex metacharacter
			// (optional quantifiers, non-capturing groups "(?:", named groups "(?<") and
			// stripping from the first '?' onward would truncate/corrupt the pattern body.
			$source_path = trim( $source_path );

			return '' === $source_path || '^' === $source_path[0] ? $source_path : '/' . ltrim( $source_path, '/' );
		}

		if ( $is_wildcard ) {
			// Same reasoning as for regex: unslashing is the caller's responsibility.
			$source_path = trim( $source_path );
			$source_path = self::strip_query_string( $source_path );
			$source_path = $case_sensitive ? $source_path : strtolower( $source_path );

			if ( '' !== $source_path && '/' !== $source_path[0] && '*' !== $source_path[0] ) {
				$source_path = '/' . $source_path;
			}

			return $source_path;
		}

		return self::normalize_match_path( $source_path, $case_sensitive, $trailing_slash );
	}

	/**
 * Build a preg pattern from a wildcard source path. Each '*' becomes a '(.*)' capture group so a trailing '*'
 * also matches the exact prefix (e.g. `/foo*` matches `/foo`). The resulting pattern anchors to the full path
 * and is case-insensitive by default.
 *
 * @param string $source         Normalized wildcard source (may contain '*').
 * @param bool   $case_sensitive Whether matching preserves letter case.
 */
	public static function build_wildcard_pattern( string $source, bool $case_sensitive = false ): string {
		$parts   = explode( '*', $source );
		$escaped = array_map( static fn( string $p ): string => preg_quote( $p, '#' ), $parts );

		return '#' . self::PCRE_LIMITS . '^' . implode( '(.*)', $escaped ) . '$#' . ( $case_sensitive ? '' : 'i' );
	}

	/**
 * Apply wildcard back-references to a target URL. Each '*' in the target is replaced by the corresponding
 * capture group from the wildcard source pattern ($1, $2, …).
 *
 * @param string $path           Current normalized request path.
 * @param string $target_url     Stored target URL (may contain '*').
 * @param bool   $case_sensitive Whether matching preserves letter case.
 */
	public static function apply_wildcard_target( string $source, string $path, string $target_url, bool $case_sensitive = false ): string {
		$pattern = self::build_wildcard_pattern( $source, $case_sensitive );
		$i       = 0;
		$target  = preg_replace_callback(
			'/\*/',
			static function () use ( &$i ): string {
				return '$' . ( ++$i );
			},
			$target_url
		);

		if ( ! is_string( $target ) ) {
			return $target_url;
		}

		$result = preg_replace( $pattern, $target, $path, 1 );

		return is_string( $result ) ? $result : $target_url;
	}

	/** Check whether a wildcard source path is valid. Must contain at least one '*', start with '/' or '*', and have no whitespace. */
	public static function is_valid_wildcard_source( string $source_path ): bool {
		return str_contains( $source_path, '*' )
			&& preg_match( '/\s/', $source_path ) === 0
			&& ( str_starts_with( $source_path, '/' ) || str_starts_with( $source_path, '*' ) );
	}

	public static function source_hash( string $source_path ): string {
		return md5( $source_path );
	}

	/** Creates a stable identity hash including every matching semantic. */
	public static function rule_hash( array $data ): string {
		$identity = array(
			'match_type'     => (string) ( $data['match_type'] ?? 'exact' ),
			'source_path'    => (string) ( $data['source_path'] ?? '' ),
			'source_query'   => (string) ( $data['source_query'] ?? '' ),
			'case_sensitive' => empty( $data['case_sensitive'] ) ? 0 : 1,
			'trailing_slash' => (string) ( $data['trailing_slash'] ?? 'ignore' ),
			'query_mode'     => (string) ( $data['query_mode'] ?? 'ignore' ),
		);

		return md5( (string) wp_json_encode( $identity ) );
	}

	/**
	 * Compare two matching rules without exposing a manual priority control.
	 * Exact rules win over wildcard rules, wildcard rules win over regexes,
	 * and the most specific rule wins within the same family.
	 */
	public static function compare_rules( array $left, array $right ): int {
		$rank = array(
			'exact'    => 0,
			'wildcard' => 1,
			'regex'    => 2,
		);
		$left_type  = (string) ( $left['match_type'] ?? 'exact' );
		$right_type = (string) ( $right['match_type'] ?? 'exact' );
		$comparison = ( $rank[ $left_type ] ?? 3 ) <=> ( $rank[ $right_type ] ?? 3 );

		if ( 0 !== $comparison ) {
			return $comparison;
		}

		// Exact-query rules are narrowest. When two rules otherwise overlap,
		// preserving the visitor query wins over silently discarding it.
		$query_rank  = array( 'exact' => 0, 'preserve' => 1, 'ignore' => 2 );
		$left_query  = $query_rank[ (string) ( $left['query_mode'] ?? 'ignore' ) ] ?? 3;
		$right_query = $query_rank[ (string) ( $right['query_mode'] ?? 'ignore' ) ] ?? 3;
		$comparison  = $left_query <=> $right_query;
		if ( 0 !== $comparison ) {
			return $comparison;
		}

		$left_specificity  = self::literal_specificity( (string) ( $left['source_path'] ?? '' ), $left_type );
		$right_specificity = self::literal_specificity( (string) ( $right['source_path'] ?? '' ), $right_type );
		$comparison        = $right_specificity <=> $left_specificity;

		return 0 !== $comparison
			? $comparison
			: (int) ( $left['id'] ?? PHP_INT_MAX ) <=> (int) ( $right['id'] ?? PHP_INT_MAX );
	}

	/**
	 * Evaluate one normalized rule against a URL without mutating state.
	 *
	 * @return array{matches:bool,target_url:string,path:string,query:string}
	 */
	public static function evaluate_rule( array $rule, string $request_uri ): array {
		$query          = self::extract_query( $request_uri );
		$query_mode     = (string) ( $rule['query_mode'] ?? 'ignore' );
		$case_sensitive = ! empty( $rule['case_sensitive'] );
		$trailing_slash = (string) ( $rule['trailing_slash'] ?? 'ignore' );
		$path           = self::normalize_match_path( $request_uri, $case_sensitive, $trailing_slash );
		$capture_path   = self::normalize_match_path_for_capture( $request_uri, $case_sensitive, $trailing_slash );
		$source         = (string) ( $rule['source_path'] ?? '' );
		$match_type     = (string) ( $rule['match_type'] ?? 'exact' );
		$matches        = false;

		if ( 'exact' === $query_mode && (string) ( $rule['source_query'] ?? '' ) !== $query ) {
			return array( 'matches' => false, 'target_url' => '', 'path' => $path, 'query' => $query );
		}

		if ( 'wildcard' === $match_type ) {
			$matches = 1 === preg_match( self::build_wildcard_pattern( $source, $case_sensitive ), $path );
		} elseif ( 'regex' === $match_type ) {
			$matches = 1 === preg_match( self::build_regex_pattern( $source, $case_sensitive ), $path );
		} else {
			$matches = self::normalize_match_path( $source, $case_sensitive, $trailing_slash ) === $path;
		}

		if ( ! $matches ) {
			return array( 'matches' => false, 'target_url' => '', 'path' => $path, 'query' => $query );
		}

		$target = (string) ( $rule['target_url'] ?? '' );
		if ( 'wildcard' === $match_type ) {
			$target = self::apply_wildcard_target( $source, $capture_path, $target, $case_sensitive );
		} elseif ( 'regex' === $match_type ) {
			$target = self::apply_regex_target( $source, $capture_path, $target, $case_sensitive );
		}
		if ( 'preserve' === $query_mode ) {
			$target = self::preserve_query( $target, $query );
		}

		return array(
			'matches'    => true,
			'target_url' => self::normalize_target_url( $target ),
			'path'       => $path,
			'query'      => $query,
		);
	}

	private static function literal_specificity( string $source, string $match_type ): int {
		if ( 'wildcard' === $match_type ) {
			return strlen( str_replace( '*', '', $source ) );
		}
		if ( 'regex' === $match_type ) {
			$literal = preg_replace( '/[\\\\.^$|()\[\]{}*+?]/', '', $source );

			return strlen( is_string( $literal ) ? $literal : '' );
		}

		return strlen( $source );
	}

	public static function preserve_query( string $target_url, string $query ): string {
		if ( '' === $query ) {
			return $target_url;
		}

		$fragment = '';
		if ( str_contains( $target_url, '#' ) ) {
			list( $target_url, $fragment ) = explode( '#', $target_url, 2 );
			$fragment                      = '#' . $fragment;
		}

		return $target_url . ( str_contains( $target_url, '?' ) ? '&' : '?' ) . $query . $fragment;
	}

	/** @return string Empty string when invalid. */
	public static function normalize_target_url( string $target_url ): string {
		$target_url = trim( wp_unslash( $target_url ) );

		if ( '' === $target_url ) {
			return '';
		}

		if ( self::is_internal_url( $target_url ) ) {
			if ( preg_match( '/[\r\n\s]/', $target_url ) ) {
				return '';
			}

			return $target_url;
		}

		$target_url = esc_url_raw( $target_url, array( 'http', 'https' ) );

		if ( '' === $target_url || ! self::is_safe_absolute_url( $target_url ) ) {
			return '';
		}

		return $target_url;
	}

	public static function is_valid_status_code( int $status_code ): bool {
		return in_array( $status_code, self::VALID_STATUS_CODES, true );
	}

	public static function is_status_only_code( int $status_code ): bool {
		return in_array( $status_code, self::STATUS_ONLY_CODES, true );
	}

	/** Check whether a non-regex source is a valid internal path. */
	public static function is_valid_internal_path( string $source_path ): bool {
		return preg_match( '#^/[^\s]*$#', $source_path ) === 1 && ! str_starts_with( $source_path, '//' );
	}

	public static function is_safe_absolute_url( string $url ): bool {
		$parts = wp_parse_url( $url );

		if ( empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return false;
		}

		if ( ! in_array( strtolower( (string) $parts['scheme'] ), array( 'http', 'https' ), true ) ) {
			return false;
		}

		if ( function_exists( 'wp_http_validate_url' ) && ! wp_http_validate_url( $url ) ) {
			return false;
		}

		return true;
	}

	/** Check if a URL is internal and path-relative. */
	public static function is_internal_url( string $url ): bool {
		return str_starts_with( $url, '/' ) && ! str_starts_with( $url, '//' );
	}

	/** @param bool   $case_sensitive Whether matching preserves letter case. */
	public static function build_regex_pattern( string $regex, bool $case_sensitive = false ): string {
		return '#' . self::PCRE_LIMITS . '(?:' . str_replace( '#', '\#', $regex ) . ')#' . ( $case_sensitive ? '' : 'i' );
	}

	/** Test whether a stored regex is valid. */
	public static function is_valid_regex( string $regex ): bool {
		if ( '' === trim( $regex ) ) {
			return false;
		}

		// Reject overly long patterns outright; combined with the catastrophic-backtracking
		// probe below this stops a stored regex from stalling every front-end request.
		if ( strlen( $regex ) > 512 ) {
			return false;
		}

		$pattern = self::build_regex_pattern( $regex );

		set_error_handler( // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_set_error_handler -- Temporarily suppresses invalid user regex warnings during validation.
			static function (): bool {
				return true;
			}
		);

		// First confirm the pattern compiles at all.
		$compiles = preg_match( $pattern, '' );

		// Then probe it against an adversarial input: a pattern that backtracks
		// catastrophically blows past the lowered limit and returns false, so we reject
		// it before it can ever reach the front-end matcher.
		$probe = false !== $compiles ? preg_match( $pattern, str_repeat( 'a', 1000 ) . '!' ) : false;

		restore_error_handler();

		return false !== $compiles && false !== $probe;
	}

	/**
 * Apply regex backreferences to a target URL.
 *
 * @param bool   $case_sensitive Whether matching preserves letter case.
 */
	public static function apply_regex_target( string $regex, string $path, string $target_url, bool $case_sensitive = false ): string {
		$pattern = self::build_regex_pattern( $regex, $case_sensitive );
		$result  = preg_replace( $pattern, $target_url, $path, 1 );

		return is_string( $result ) ? $result : $target_url;
	}

	/** @return string|null */
	public static function target_to_local_path( string $target_url ): ?string {
		if ( self::is_internal_url( $target_url ) ) {
			return self::normalize_path( $target_url );
		}

		$home_host   = wp_parse_url( home_url(), PHP_URL_HOST );
		$target_host = wp_parse_url( $target_url, PHP_URL_HOST );

		if ( ! $home_host || ! $target_host || strtolower( (string) $home_host ) !== strtolower( (string) $target_host ) ) {
			return null;
		}

		return self::normalize_path( $target_url );
	}

	/** Extract only path from a path or absolute URL. */
	private static function extract_path( string $value ): string {
		$value = self::strip_query_string( $value );
		$path  = wp_parse_url( $value, PHP_URL_PATH );

		return is_string( $path ) && '' !== $path ? $path : $value;
	}

	private static function strip_query_string( string $value ): string {
		$value = preg_replace( '/[?#].*$/', '', $value );

		return is_string( $value ) ? $value : '';
	}
}
