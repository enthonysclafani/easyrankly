<?php
/**
 * Classic meta box save handler. $_POST is wp_unslash()ed here and sanitized by
 * erankly_sanitize_registered_meta(); update_post_meta() receives wp_slash()ed values so literal
 * backslashes (JSON-LD) survive. Fields not rendered (breadcrumbs off, simplified mode) are skipped to
 * keep stored values. Simplified "hide from search results" = noindex + disable_sitemap only.
 */
defined( 'ABSPATH' ) || exit;
function erankly_save_meta_box( int $post_id, WP_Post $post ): void {
	if ( ! isset( $_POST['erankly_meta_box_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['erankly_meta_box_nonce'] ) ), 'erankly_save_meta_box' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$fields = array(
		'_erankly_title'           => 'erankly_title',
		'_erankly_description'     => 'erankly_description',
		'_erankly_canonical'       => 'erankly_canonical',
		'_erankly_breadcrumb_name' => 'erankly_breadcrumb_name',
	);
	if ( ! (bool) erankly_get_setting( 'enable_breadcrumbs', 1 ) ) {
		unset( $fields['_erankly_breadcrumb_name'] );
	}
	$fields = array_merge(
		$fields,
		array(
			'_erankly_og_title'            => 'erankly_og_title',
			'_erankly_og_description'      => 'erankly_og_description',
			'_erankly_twitter_title'       => 'erankly_twitter_title',
			'_erankly_twitter_description' => 'erankly_twitter_description',
			'_erankly_twitter_card_type'   => 'erankly_twitter_card_type',
			'_erankly_og_image_url'        => 'erankly_og_image_url',
			'_erankly_og_image_alt'        => 'erankly_og_image_alt',
			'_erankly_twitter_image_url'   => 'erankly_twitter_image_url',
			'_erankly_twitter_image_alt'   => 'erankly_twitter_image_alt',
		)
	);
	$simplified_mode = (bool) erankly_get_setting( 'simplified_mode', 1 );
	if ( $simplified_mode ) {
		unset(
			$fields['_erankly_canonical'],
			$fields['_erankly_breadcrumb_name'],
			$fields['_erankly_og_title'],
			$fields['_erankly_og_description'],
			$fields['_erankly_twitter_title'],
			$fields['_erankly_twitter_description'],
			$fields['_erankly_twitter_card_type'],
			$fields['_erankly_og_image_url'],
			$fields['_erankly_og_image_alt'],
			$fields['_erankly_twitter_image_url'],
			$fields['_erankly_twitter_image_alt']
		);
	}
	foreach ( $fields as $key => $field ) {
		$raw_value = isset( $_POST[ $field ] ) ? wp_unslash( $_POST[ $field ] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above; sanitized by erankly_sanitize_registered_meta() on the next line.
		$value     = erankly_sanitize_registered_meta( $raw_value, $key );
		if ( '' === $value || 0 === $value ) {
			delete_post_meta( $post_id, $key );
		} else {
			update_post_meta( $post_id, $key, wp_slash( $value ) );
		}
	}
	// The attachment id is the frontend's fallback for an empty URL. The classic form has no id field, so a
	// cleared URL has to drop the companion id too: otherwise "remove the image" left an imported id behind
	// and the picture kept being emitted.
	$image_id_companions = array(
		'_erankly_og_image_url'      => '_erankly_og_image_id',
		'_erankly_twitter_image_url' => '_erankly_twitter_image_id',
	);

	foreach ( $image_id_companions as $url_key => $id_key ) {
		if ( isset( $fields[ $url_key ] ) && '' === (string) get_post_meta( $post_id, $url_key, true ) ) {
			delete_post_meta( $post_id, $id_key );
		}
	}

	$hide_from_search_results = $simplified_mode && isset( $_POST['erankly_hide_from_search_results'] );
	$existing_index_directive = isset( $_POST['erankly_existing_index_directive'] ) ? sanitize_key( wp_unslash( $_POST['erankly_existing_index_directive'] ) ) : 'inherit';
	$existing_hide            = ! empty( $_POST['erankly_existing_hide'] );
	if ( $simplified_mode ) {
		if ( $hide_from_search_results ) {
			update_post_meta( $post_id, '_erankly_index_directive', 'noindex' );
			update_post_meta( $post_id, '_erankly_noindex', '1' );
		} elseif ( $existing_hide && 'noindex' === $existing_index_directive ) {
			update_post_meta( $post_id, '_erankly_index_directive', 'inherit' );
			delete_post_meta( $post_id, '_erankly_noindex' );
		}
	} else {
		$directive_fields = array(
			'_erankly_index_directive'   => 'erankly_index_directive',
			'_erankly_follow_directive'  => 'erankly_follow_directive',
			'_erankly_archive_directive' => 'erankly_archive_directive',
			'_erankly_snippet_directive' => 'erankly_snippet_directive',
			'_erankly_image_directive'   => 'erankly_image_directive',
			'_erankly_max_snippet'       => 'erankly_max_snippet',
			'_erankly_max_video_preview' => 'erankly_max_video_preview',
			'_erankly_max_image_preview' => 'erankly_max_image_preview',
		);
		foreach ( $directive_fields as $key => $field ) {
			$value = erankly_sanitize_registered_meta( isset( $_POST[ $field ] ) ? wp_unslash( $_POST[ $field ] ) : '', $key ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above; value is sanitized by erankly_sanitize_registered_meta().
			if ( '' === $value || 'inherit' === $value ) {
				delete_post_meta( $post_id, $key );
			} else {
				update_post_meta( $post_id, $key, $value );
			}
		}
		foreach ( array(
			'noindex'   => 'index',
			'nofollow'  => 'follow',
			'noarchive' => 'archive',
		) as $legacy => $axis ) {
			$value = isset( $_POST[ 'erankly_' . $axis . '_directive' ] ) ? sanitize_key( wp_unslash( $_POST[ 'erankly_' . $axis . '_directive' ] ) ) : 'inherit';
			if ( $legacy === $value ) {
				update_post_meta( $post_id, '_erankly_' . $legacy, '1' );
			} else {
				delete_post_meta( $post_id, '_erankly_' . $legacy );
			}
		}
		if ( isset( $_POST['erankly_indexifembedded'] ) ) {
			update_post_meta( $post_id, '_erankly_indexifembedded', '1' );
		} else {
			delete_post_meta( $post_id, '_erankly_indexifembedded' );
		}
	}
	$booleans = array(
		'_erankly_exclude_search'    => isset( $_POST['erankly_exclude_search'] ),
		'_erankly_exclude_archive'   => isset( $_POST['erankly_exclude_archive'] ),
		'_erankly_exclude_from_news' => isset( $_POST['erankly_exclude_from_news'] ),
	);
	if ( ! $simplified_mode || $hide_from_search_results || $existing_hide ) {
		$booleans['_erankly_disable_sitemap'] = $hide_from_search_results || ( ! $simplified_mode && isset( $_POST['erankly_disable_sitemap'] ) );
	}
	foreach ( $booleans as $key => $enabled ) {
		if ( $enabled ) {
			update_post_meta( $post_id, $key, '1' );
		} else {
			delete_post_meta( $post_id, $key );
		}
	}
	if ( ! $simplified_mode ) {
		$GLOBALS['erankly_schema_blocks_previous'] = get_post_meta( $post_id, '_erankly_schema_blocks', true );
		$raw_disabled_types = isset( $_POST['erankly_schema_disabled_types'] ) ? wp_unslash( $_POST['erankly_schema_disabled_types'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above; sanitized by erankly_sanitize_registered_meta().
		if ( is_string( $raw_disabled_types ) ) {
			$disabled_types = preg_split( '/[\r\n,]+/', $raw_disabled_types );
		} elseif ( is_array( $raw_disabled_types ) ) {
			$disabled_types = $raw_disabled_types;
		} else {
			$disabled_types = array();
		}
		$extra_disabled = isset( $_POST['erankly_schema_disabled_types_extra'] ) ? wp_unslash( $_POST['erankly_schema_disabled_types_extra'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above; split and sanitized below.
		if ( is_string( $extra_disabled ) && '' !== trim( $extra_disabled ) ) {
			$disabled_types = array_merge( is_array( $disabled_types ) ? $disabled_types : array(), preg_split( '/[\r\n,]+/', $extra_disabled ) );
		}
		$complex_fields     = array(
			'_erankly_primary_terms'         => isset( $_POST['erankly_primary_terms'] ) ? wp_unslash( $_POST['erankly_primary_terms'] ) : array(), // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above; sanitized by erankly_sanitize_registered_meta() below.
			'_erankly_schema_blocks'         => isset( $_POST['erankly_schema_blocks'] ) ? wp_unslash( $_POST['erankly_schema_blocks'] ) : array(), // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above; sanitized by erankly_sanitize_registered_meta() below.
			'_erankly_schema_disabled_types' => is_array( $disabled_types ) ? $disabled_types : array(),
		);
		foreach ( $complex_fields as $key => $raw_value ) {
			$value = erankly_sanitize_registered_meta( $raw_value, $key );
			if ( empty( $value ) ) {
				delete_post_meta( $post_id, $key );
			} else {
				update_post_meta( $post_id, $key, wp_slash( $value ) );
			}
		}
		$schema_mode = erankly_sanitize_registered_meta( isset( $_POST['erankly_schema_mode'] ) ? wp_unslash( $_POST['erankly_schema_mode'] ) : '', '_erankly_schema_mode' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above; value is sanitized by erankly_sanitize_registered_meta().
		if ( '' === $schema_mode || 'default' === $schema_mode ) {
			delete_post_meta( $post_id, '_erankly_schema_mode' );
		} else {
			update_post_meta( $post_id, '_erankly_schema_mode', $schema_mode );
		}
	}
	do_action( 'erankly_save_meta_box', $post_id, $post );
}
